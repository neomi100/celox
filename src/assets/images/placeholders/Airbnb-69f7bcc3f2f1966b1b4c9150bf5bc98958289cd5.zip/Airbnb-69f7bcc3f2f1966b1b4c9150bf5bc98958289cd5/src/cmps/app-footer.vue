<template>
  <section class="main-layout footer-container">
      <div class="footer-contant"> 
          <p class="logo"> HomeAway </p>
 <div class="rights-container"> 
          <p> © 2020 HomeAway, Inc. All rights reserved </p>
      </div>
   <ul class="social-links clean-list">
        <li>
          <a class="facebook" href="https://www.facebook.com/eran.sevil/">
            <button><img class="footer-img" src="../assets/imgs/icons/facebook-icon.svg" /></button></a>
        </li>
        <li>
          <a class="twitter" href="https://www.linkedin.com/in/eran-sevil-68ba43171/"><button><img class="footer-img" src="../assets/imgs/icons/twitter-icon.svg" /></button></a>
        </li>
        <li>
          <a class="linkedin" href="https://twitter.com/EranSevil"><button><img class="footer-img" src="../assets/imgs/icons/linkedin-icon.svg" /></button>
          </a>
        </li>
      </ul>
      
            </div>

  </section>
</template>

<script>
export default {

}
</script>

