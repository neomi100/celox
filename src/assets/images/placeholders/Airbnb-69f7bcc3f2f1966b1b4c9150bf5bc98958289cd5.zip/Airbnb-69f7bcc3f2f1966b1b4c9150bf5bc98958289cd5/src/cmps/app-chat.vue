<template>
  <section>
      <h2>i am chat </h2>
  </section>
</template>

<script>
export default {

}
</script>

<style>

</style>