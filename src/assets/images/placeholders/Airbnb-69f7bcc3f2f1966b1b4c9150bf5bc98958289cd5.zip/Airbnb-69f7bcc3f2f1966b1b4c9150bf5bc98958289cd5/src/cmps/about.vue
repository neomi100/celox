<template>
  <section class="">
    <h1 class="about-section-title">Tell Me More</h1>
    <div class="about-container">
      <div class="about-card-homeaway">
        <h2 class="about-title">What is HomeAway?</h2>
        <p class="about-txt">
          HomeAway connects people with places to stay and things to do around
          the world. The community is powered by hosts, who provide their guests
          with the unique opportunity to travel like a local.
        </p>
      </div>
      <div class="about-card-homeaway">
        <h2 class="about-title">What is hosting?</h2>
        <p class="about-txt">
          HomeAway connects people with places to stay and things to do around
          the world. The community is powered by hosts, who provide their guests
          with the unique opportunity to travel like a local.
        </p>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  
};
</script>

<style>
</style>