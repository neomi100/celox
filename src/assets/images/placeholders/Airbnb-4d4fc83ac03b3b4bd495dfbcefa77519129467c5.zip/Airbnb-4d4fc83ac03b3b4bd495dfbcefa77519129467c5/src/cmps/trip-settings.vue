<template>
  <section>
      <!-- <h2>trip setting</h2>
      Check-in:<input type="date"/>
      Check-out:<input type="date"/>
      <select>Guests
        <option>
        </select> -->

  </section>
</template>

<script>
export default {

}
</script>

<style>

</style>