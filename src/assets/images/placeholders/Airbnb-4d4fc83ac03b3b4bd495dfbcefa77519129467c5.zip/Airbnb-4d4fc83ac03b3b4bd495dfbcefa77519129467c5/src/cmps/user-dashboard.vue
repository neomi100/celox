<template>
  <section>
    i am user dashboard
  </section>
</template>

<script>
export default {
  props: ["user"],
};
</script>

<style>
</style>