<template>
  <section class="home-bannar-container">
      <div class="bannar-content">
          <h2 class="bannar-txt-one">Home is where our story begins...</h2>
            <router-link class="router" :to="`/stay`">
          <button 
           class="exp-btn">Explore</button>
            </router-link>
          <div class="quate2">
          <h4 class="quate2-txt">All You Need Is PASSPORT . . .</h4>

          </div>
      </div>
  </section>
</template>

<script>
export default {

}
</script>
